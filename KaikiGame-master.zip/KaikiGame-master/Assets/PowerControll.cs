﻿using UnityEngine;
using System.Collections;

public class PowerControll : MonoBehaviour {

	[Header("Player Controller")]
	public GameObject player;

	[Header("Stone Power")]
	public GameObject auxStone;

	[Header("Water Power")]
	public GameObject auxWater;

	[Header("Air Power")]
	public float jumpForce;

	[Header("Fire Power")]
	public GameObject auxFire;


	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag("Player");
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void Air ()  {
		player.transform.GetComponent<Rigidbody2D>().AddForce(new Vector2(0,jumpForce*2));
	}
	public void Stone ()  {
		auxStone = GameObject.FindGameObjectWithTag("");
		Destroy(auxStone,0f);
	}
	public void Water ()  {
		auxWater = GameObject.FindGameObjectWithTag("");
		Destroy(auxWater,0f);
	}
	public void Fire ()  {
		auxFire = GameObject.FindGameObjectWithTag("");
		Destroy(auxFire,0f);
	}

}
