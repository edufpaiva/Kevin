﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    PlayerMovement playerMovement;
    public GameObject gameManager;
    GameOverManager gameOver;
    private PowerMove powerMove;
    void Start()
    {
        playerMovement = GetComponent<PlayerMovement>();
        powerMove = GetComponent<PowerMove>();
        gameOver = gameManager.GetComponent<GameOverManager>();
    }

    void Update()
    {
        playerMovement.MoveCharacterToRight();
    }

    public void FireController()
    {
        powerMove.FirePower();
    }
    public void WaterController()
    {
        powerMove.WaterPower();
    }
    public void WindController()
    {
        powerMove.WindPower();
    }
    public void EarthController()
    {
        powerMove.EarthPower();
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        Debug.Log("HEUAHEUAHUEHAUEAHAUHAHUEHUEAUHEUAHEUHAU");
        if (other.gameObject.tag == "Fire" || other.gameObject.tag == "Water" || other.gameObject.tag == "Earth" || other.gameObject.tag == "Wind")
            gameOver.IsGameOver();
    }

}
