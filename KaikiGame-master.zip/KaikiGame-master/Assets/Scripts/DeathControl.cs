﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class DeathControl : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D other)
    {
        SceneManager.LoadScene("Game1");
    }
}
