﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class GameOverManager : MonoBehaviour {

    public GameObject gameOverWindow;
    // Use this for initialization

    public void IsGameOver()
    {
        gameOverWindow.SetActive(true);
        Time.timeScale = 0;
    }

    public void GoToMenu()
    {
        SceneManager.LoadScene("MainMenu");
        Time.timeScale = 1.0f;
    }

    public void Reload()
    {
        SceneManager.LoadScene("Gameplay");
        Time.timeScale = 1.0f;
    }

}
