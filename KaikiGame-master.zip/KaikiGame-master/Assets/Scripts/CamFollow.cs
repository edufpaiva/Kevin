﻿using UnityEngine;
using System.Collections;

public class CamFollow : MonoBehaviour {
    public Transform player;
    public Vector3 offset;
	// Use this for initialization
	void Update () {
        transform.position = new Vector3(player.position.x + offset.x, offset.y, offset.z); // Camera follows the player with specified offset position
    }
}
