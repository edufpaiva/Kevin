﻿using UnityEngine;
using System.Collections;

public class PowerMove : MonoBehaviour {
    private Animator playerAnim;
	// Use this for initialization
	void Start () {
        playerAnim = GetComponent<Animator>();
	}

    public void FirePower()
    {
        playerAnim.SetTrigger("FirePower");
    }
    public void WaterPower()
    {
        playerAnim.SetTrigger("WaterPower");
    }
    public void EarthPower()
    {
        playerAnim.SetTrigger("EarthPower");
    }
    public void WindPower()
    {
        playerAnim.SetTrigger("WindPower");
    }
}
