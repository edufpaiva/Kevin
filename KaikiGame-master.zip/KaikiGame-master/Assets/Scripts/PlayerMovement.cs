﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
    
    private Animator playerAnimator;

	// Use this for initialization
	void Awake () {
        playerAnimator = GetComponent<Animator>();
	}
	
    public void MoveCharacterToRight()
    {
        playerAnimator.SetTrigger("Moving");
    }

}
