﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour {
    public AnimationClip myAnim;
	// Use this for initialization
	void Start () {
       // myAnim = GetComponent<AnimationClip>();
        StartCoroutine(LoadOtherLevel());
	}
	
	IEnumerator LoadOtherLevel () {
        yield return new WaitForSeconds(myAnim.length);

        SceneManager.LoadSceneAsync("MainMenu");
    }
}
