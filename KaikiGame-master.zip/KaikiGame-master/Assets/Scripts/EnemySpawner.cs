﻿using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour {
    public GameObject[] enemyList;
    public Transform[] spawnPoints;
    public float spawnTime = 2f;
    // Use this for initialization
    void Start () {
        InvokeRepeating("InstantiateEnemy", spawnTime, spawnTime);
    }
	
    void InstantiateEnemy()
    {
        int spawnPointIndex = Random.Range(0, spawnPoints.Length);
        Instantiate(enemyList[Random.Range(0,4)],spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);

        foreach (GameObject enemy in enemyList)
        {
            GetComponent<Transform>().position = new Vector2(10 * Time.deltaTime,0);
        }
    }
}
