﻿using UnityEngine;
using System.Collections;

public class PowerButtonsController : MonoBehaviour {

    public GameObject player;
    private PlayerController playerController;

	// Use this for initialization
	void Start () {
        playerController = player.GetComponent<PlayerController>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void FireButtonPresset()
    {

        playerController.FireController();
    }

    public void WaterButtonPresset()
    {
        playerController.WaterController();
    }

    public void WindButtonPresset()
    {
        playerController.WindController();
    }

    public void EarthButtonPresset()
    {
        playerController.EarthController();
    }
}
